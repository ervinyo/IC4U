from flask import Flask, jsonify, render_template, request
import traceback
from flask_restful import Resource, Api
import speech_recognition as sr
import webbrowser as wb
import time


app = Flask(__name__)
api = Api(app)

class HelloWorld(Resource):
    def get(self):
        #return {'hello': 'world'}
        #wb.open('http://127.0.0.1:5000/')
        return render_template('home.html')
        #return "http://127.0.0.1:5000/"

#api.add_resource(HelloWorld, '/')

@app.route('/')
def index():
    return render_template('home.html')

@app.route('/youtube/')
def youtube():
    return render_template('youtube.html')	


@app.route('/ajax1', methods=['GET', 'POST'])
def ajax1():
    try:
        user =  request.form.get('username')
        return "1"
    except Exception:
        return "error"
		
@app.route('/openapp', methods=['GET', 'POST'])	
def openapp():
    try:
        f = open ('result.txt','r')
        #print (f.read())
        return f.read()
    except Exception:
        return "error"

@app.route('/voice', methods=['GET', 'POST'])	
def voice():
    r = sr.Recognizer() 
    with sr.Microphone() as source:
        f = open ('result.txt','w')
        f.write("wait")
        #print ("Please wait a moment...  Calibrating microphone NOW~")
        # listen for 1 seconds and create the ambient noise energy level 
        r.adjust_for_ambient_noise (source, duration=2) 
        #print ("Now, please say something !!!")
        res = 'tes'    
        audio = r.listen (source)
    try:
        #f = open ('result.txt','w')
        text = r.recognize_google(audio, language="EN")
        if text == 'close':
            return "close"
        res = (text)
        
        #print (r.recognize_google(audio, language="EN"), file = f)
        #f_text =  text + ".com"
        #wb.get (chrome_path) .open (f_text)
        #wb.open('http://127.0.0.1:5000/' + f_text)
        #print ("What you said has been saved as [result.txt] :)")
        return res
    except sr.UnknownValueError:
        return ("0")
    except sr.RequestError as e:
        return ("0")
    #f.close()

#######################################################

#######################################################
if __name__ == '__main__':
   app.run(debug = True)
